//
//  ConversationCellProtocol.swift
//  TinkoffChat
//
//  Created by Алексей ]Чанов on 24/02/2019.
//  Copyright © 2019 Алексей Чанов. All rights reserved.
//

import Foundation

protocol MessageCellCongiguration : class {
    
    var text : String? {get set}
    
}
